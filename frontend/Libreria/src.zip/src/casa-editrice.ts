export interface CasaEditrice {}
